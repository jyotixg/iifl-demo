import './App.css';
import FirstComponent from './FirstComponent';

function App() {
  return (
    <div className="App">
      <FirstComponent />
    </div>
  );
}

export default App;
